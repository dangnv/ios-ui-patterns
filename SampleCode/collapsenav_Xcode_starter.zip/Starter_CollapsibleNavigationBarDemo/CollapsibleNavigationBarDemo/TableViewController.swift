//
//  TableViewController.swift
//  CollapsibleNavigationBarDemo
//
//  Created by Clint Cabanero on 3/10/16.
//  Copyright © 2016 ClintCabanero. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
